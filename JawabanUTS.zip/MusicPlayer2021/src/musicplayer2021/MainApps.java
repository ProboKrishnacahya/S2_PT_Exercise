/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musicplayer2021;

import com.sun.org.apache.bcel.internal.generic.InstructionConstants;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author caeciliacitra
 */
public class MainApps {

    private Playlist library = new Playlist();
    private ArrayList<Playlist> lists = new ArrayList<>();
    
    public MainApps(){
        addMusicToLibrary();
    }

    public void addMusicToLibrary() {
        Music m;
        m = new Music("BTS", "Dynamite", "K-Pop", 200);
        library.addMusic(m);
        m = new Music("Afgan", "Sudah", "Pop", 195);
        library.addMusic(m);
        m = new Music("Pamungkas", "To The Bone", "Pop", 200);
        library.addMusic(m);
        m = new Music("Ardhito Pramono", "Bitterlove", "Pop Jazz", 216);
        library.addMusic(m);
        m = new Music("BTS", "DNA", "K-Pop", 256);
        library.addMusic(m);
        m = new Music("Didi Kempot", "Pamer Bojo", "Campursari", 240);
        library.addMusic(m);
        m = new Music("Queen", "Bohemian Rhapsody", "Rock", 389);
        library.addMusic(m);
        m = new Video("Pentatonix", "Mary Did You Know", "Pop", 220, 1024, 960);
        library.addMusic(m);
        m = new Video("Blackpink", "How +You Like", "K-Pop", 184, 1024, 960);
        library.addMusic(m);
        m = new Video("Justin Bieber feat. Arianne Grande", "Stuck With You", "Pop", 197, 640, 480);
        library.addMusic(m);
        library.setName("Library");
    }

    public void run() {
        System.out.println("=======================");
        System.out.println("WELCOME TO DURIAN MUSIC");
        System.out.println("=======================");
        Scanner s;
        int pilih = -1;
        while (pilih != 0) {
            System.out.println("Menu");
            System.out.println("1. Play Music");
            System.out.println("2. Manage Playlists");
            System.out.println("3. Add New Music to Library");
            System.out.println("0. Exit");
            System.out.println("Choose : ");
            s = new Scanner(System.in);
            pilih = s.nextInt();
            int n;
            switch (pilih) {
                case 1:
                    n = -1;
                    boolean back2playlist = true;
                    while (back2playlist) {
                        System.out.println("=== PLAY MUSIC FROM ===");
                        for (int i = 0; i < lists.size(); i++) {
                            Playlist p = lists.get(i);
                            System.out.println((i + 1) + ". " + p.getName() + " : " + p.getCollectionSize()+ " musics (" +p.getDuration() + " secs)");
                        }
                        System.out.println((lists.size() + 1) + ". " + library.getName() + " : " + library.getCollectionSize()+ " musics (" + library.getDuration() + " secs)");
                        System.out.println("0. Back");
                        System.out.println("Choose :");
                        n = s.nextInt() - 1;
                        Playlist p;
                        if (n >= 0) {
                            if (n < lists.size()) {
                                p = lists.get(n);
                            } else {
                                p = library;
                            }
                            p.chooseMusic(0);
                            String what = "";
                            System.out.println("Radomize Musics (Y/N) ?");
                            String r = s.next();
                            s = new Scanner(System.in);
                            System.out.println("Loop Playlist (Y/N) ??");
                            String l = s.next();
                            boolean random, loop;
                            if (r.equalsIgnoreCase("y")) {
                                random = true;
                            } else {
                                random = false;
                            }
                            if (l.equalsIgnoreCase("y")) {
                                loop = true;
                            } else {
                                loop = false;
                            }
                            while (!what.equalsIgnoreCase("q")) {
                                System.out.println("*************");
                                p.playMusic();
                                System.out.println("*************");
                                System.out.println("Choose: Prev(<) | Next (>) | Quit Playlist(q):");
                                System.out.println("");
                                s = new Scanner(System.in);
                                what = s.next();
                                if (what.equalsIgnoreCase("<")) {
                                    p.prevMusic(random, loop);
                                } else if (what.equalsIgnoreCase(">")) {
                                    p.nextMusic(random, loop);
                                }
                            }

                        } else {
                            back2playlist = false;
                        }
                    }
                    break;

                case 2:
                    back2playlist = true;
                    n = -1;
                    while (back2playlist) {
                        System.out.println("=== MANAAGE PLAYLIST");
                        for (int i = 0; i < lists.size(); i++) {
                            Playlist p = lists.get(i);
                            System.out.println((i + 1) + ". " + p.getName() + " (" + p.getDuration() + " secs)");
                        }
                        System.out.println((lists.size() + 1) + ". New Playlist :");
                        System.out.println("0. Back");
                        System.out.print("Choose : ");
                        s = new Scanner(System.in);
                        n = s.nextInt() - 1;
                        if (n >= 0 && n < lists.size()) {
                            Playlist p = lists.get(n);
                            int c = -1;
                            //while (c != 0) {
                            System.out.println("PLAYLIST : " + p.getName());
                            p.showMusics();;
                            System.out.println("To Do : 1) Add Music | 2) Remove Music | 0) Bacj");
                            c = s.nextInt();
                            if (c == 1) {
                                System.out.println("Songs to add");
                                library.showMusics();
                                System.out.println("Choose (separate with , no space needed): ");
                                String input = s.next();
                                String[] ids = input.split(",");
                                for (String st : ids) {
                                    int id = Integer.valueOf(st) - 1;
                                    p.addMusic(library.getMusic(id));
                                    
                                }
                                System.out.println("-------");
                                System.out.println("Musics are added to playlist");
                                System.out.println("");
                            } else if (c == 2) {
                                System.out.println("Song(s) to Remove");
                                p.showMusics();
                                System.out.println("Choose (separate with , no space needed): ");
                                String input = s.next();
                                String[] ids = input.split(",");
                                for (int i = ids.length-1; i>=0; i--) {
                                    int id = Integer.valueOf(ids[i]) - 1;
                                    p.removeMuisc(id);
                                    
                                }
                                System.out.println("-------");
                                System.out.println("Musics are removed from playlist");
                                     System.out.println("");
                            }
                            //}
                        } else if (n == lists.size()) {
                            Playlist p = new Playlist();
                            s = new Scanner(System.in);
                            System.out.println("Playlist's Name : ");
                            String name = s.nextLine();
                            p.setName(name);
                            lists.add(p);
                            System.out.println("New Playlist is Added");

                        } else {
                            back2playlist = false;
                        }
                    }
                    break;
                case 3:
                    String again = "y";
                    while (again.equalsIgnoreCase("y")) {
                        s = new Scanner(System.in);
                        System.out.println("=== ADD NEW MUSIC TO LIBRARY ===");
                        System.out.print("Type: 1) Audio 2) Video : ");
                        int type = s.nextInt();
                        System.out.print("Singer : ");
                        s = new Scanner(System.in);
                        String singer = s.nextLine();
                        s = new Scanner(System.in);
                        System.out.print("Title :");
                        String title = s.nextLine();
                        s = new Scanner(System.in);
                        System.out.print("Genre : ");
                        String genre = s.nextLine();
                        s = new Scanner(System.in);
                        System.out.print("Duration in Seconds : ");
                        int secs = s.nextInt();
                        if (type == 1) {
                            Music m = new Music(singer, title, genre, secs);
                            library.addMusic(m);
                        } else {
                            System.out.println("Video Dimension :");
                            System.out.print("Length :");
                            int l = s.nextInt();
                            System.out.print("Width : ");
                            int w = s.nextInt();
                            Video v = new Video(singer, title, genre, secs, l, w);
                            library.addMusic(v);
                        }
                        System.out.println("Mysic is added to Library");
                        System.out.println("Add More (Y/N) ?");
                        s = new Scanner(System.in);
                        again = s.next();
                    }

                    break;
            }

        }
    }

}
