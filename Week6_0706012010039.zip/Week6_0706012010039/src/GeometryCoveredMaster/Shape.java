package GeometryCoveredMaster;

import java.util.Random;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public interface Shape {

    public double luas();

    public double keliling();

    public void setR(int radius);

    public void getR();

}
