package com.cahyaa.week12_0706012010039;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class display_collection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_collection);
    }
}