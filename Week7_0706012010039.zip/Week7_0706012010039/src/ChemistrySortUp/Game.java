package ChemistrySortUp;

import java.util.Random;
import java.util.Scanner;
import java.util.Stack;
import java.lang.Math;
import java.util.ArrayList;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class Game {

    ArrayList<Tube> globalArrayList = new <Tube>ArrayList();

    public void run() {
        int RandomNum;
        int pindah1;
        int pindah2;
        int skorBertambah = 0;
//        int max = 2;
//        int min = 0;
//        int range = max - min + 1;
        boolean isCocok1 = false;
        boolean isCocok2 = false;
        boolean isCocok3 = false;
        boolean isCocok4 = false;
        boolean isCocok5 = false;

        Random random = new Random();
        RandomNum = random.nextInt(3);

        ArrayList bahanKimia = new ArrayList();
        bahanKimia.add("0");
        bahanKimia.add("0");
        bahanKimia.add("0");
        bahanKimia.add("0");
        bahanKimia.add("1");
        bahanKimia.add("1");
        bahanKimia.add("1");
        bahanKimia.add("1");
        bahanKimia.add("2");
        bahanKimia.add("2");
        bahanKimia.add("2");
        bahanKimia.add("2");

        Tube tabung1 = new Tube();
        Tube tabung2 = new Tube();
        Tube tabung3 = new Tube();
        Tube tabung4 = new Tube();
        Tube tabung5 = new Tube();

//        Object[] data1 = new Object[4];
//        Object[] data2 = new Object[4];
//        Object[] data3 = new Object[4];
//        Object[] data4 = new Object[4];
//        Object[] data5 = new Object[4];
        for (int i = 0; i < 4; i++) {
            int angkaRandom1 = random.nextInt(bahanKimia.size());
            tabung1.push(bahanKimia.get(angkaRandom1));
            bahanKimia.remove(angkaRandom1);

            int angkaRandom2 = random.nextInt(bahanKimia.size());
            tabung2.push(bahanKimia.get(angkaRandom2));
            bahanKimia.remove(angkaRandom2);

            int angkaRandom3 = random.nextInt(bahanKimia.size());
            tabung3.push(bahanKimia.get(angkaRandom3));
            bahanKimia.remove(angkaRandom3);
        }

        String playOrExit = null;
        String p = null;
        String q = null;
        Scanner bermain = new Scanner(System.in);

        do {
            while (skorBertambah < 3) {
                Object item = 0;
                System.out.println("\n=================");
                System.out.println("CHEMISTRY SORT-UP");
                System.out.println("=================");
                System.out.println("\nHomogenous Tube : " + skorBertambah);

//        for (int j = 0; j < 4; j++) {
//            int rand = (int) (Math.random() * range) + min;
//            System.out.println("| " + rand + " |" + "\t" + "| " + rand + " |" + "\t" + "| " + rand + " |" + "\t" + "| " + " " + " |" + "\t" + "| " + " " + " |");
//        }
                for (int i = 3; i > -1; i--) {
                    if (tabung1.globalArrayList.size() > i && tabung1.globalArrayList.size() > 0) {
                        System.out.print("| " + tabung1.globalArrayList.get(i) + " | ");
                    } else {
                        System.out.print("|   | ");
                    }
                    if (tabung2.globalArrayList.size() > i && tabung2.globalArrayList.size() > 0) {
                        System.out.print("| " + tabung2.globalArrayList.get(i) + " | ");
                    } else {
                        System.out.print("|   | ");
                    }
                    if (tabung3.globalArrayList.size() > i && tabung3.globalArrayList.size() > 0) {
                        System.out.print("| " + tabung3.globalArrayList.get(i) + " | ");
                    } else {
                        System.out.print("|   | ");
                    }
                    if (tabung4.globalArrayList.size() > i && tabung4.globalArrayList.size() > 0) {
                        System.out.print("| " + tabung4.globalArrayList.get(i) + " | ");
                    } else {
                        System.out.print("|   | ");
                    }
                    if (tabung5.globalArrayList.size() > i && tabung5.globalArrayList.size() > 0) {
                        System.out.print("| " + tabung5.globalArrayList.get(i) + " | ");
                    } else {
                        System.out.print("|   | ");
                    }
                    System.out.println("");
                }
                System.out.println("  1     2     3     4     5");
                System.out.print("Move From : ");
                Scanner s = new Scanner(System.in);
                pindah1 = s.nextInt();
                System.out.print("To : ");
                pindah2 = s.nextInt();

                if (pindah1 == 1) {
                    if (pindah2 == 2) {
                        if (tabung1.isEmpty() == false) {
                            if (tabung2.isEmpty() == true) {
                                item = tabung1.pop();
                                tabung2.push(item);
                            } else {
                                if (tabung1.peek() == tabung2.peek()) {
                                    if (tabung2.isFull() == false) {
                                        item = tabung1.pop();
                                        tabung2.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 3) {
                        if (tabung1.isEmpty() == false) {
                            if (tabung3.isEmpty() == true) {
                                item = tabung1.pop();
                                tabung3.push(item);
                            } else {
                                if (tabung1.peek() == tabung3.peek()) {
                                    if (tabung3.isFull() == false) {
                                        item = tabung1.pop();
                                        tabung3.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 4) {
                        if (tabung1.isEmpty() == false) {
                            if (tabung4.isEmpty() == true) {
                                item = tabung1.pop();
                                tabung4.push(item);
                            } else {
                                if (tabung1.peek() == tabung4.peek()) {
                                    if (tabung4.isFull() == false) {
                                        item = tabung1.pop();
                                        tabung4.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 5) {
                        if (tabung1.isEmpty() == false) {
                            if (tabung5.isEmpty() == true) {
                                item = tabung1.pop();
                                tabung5.push(item);
                            } else {
                                if (tabung1.peek() == tabung5.peek()) {
                                    if (tabung5.isFull() == false) {
                                        item = tabung1.pop();
                                        tabung5.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    }
                } else if (pindah1 == 2) {
                    if (pindah2 == 1) {
                        if (tabung2.isEmpty() == false) {
                            if (tabung1.isEmpty() == true) {
                                item = tabung2.pop();
                                tabung1.push(item);
                            } else {
                                if (tabung2.peek() == tabung1.peek()) {
                                    if (tabung2.isFull() == false) {
                                        item = tabung2.pop();
                                        tabung1.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 3) {
                        if (tabung2.isEmpty() == false) {
                            if (tabung3.isEmpty() == true) {
                                item = tabung2.pop();
                                tabung3.push(item);
                            } else {
                                if (tabung2.peek() == tabung3.peek()) {
                                    if (tabung3.isFull() == false) {
                                        item = tabung2.pop();
                                        tabung3.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 4) {
                        if (tabung2.isEmpty() == false) {
                            if (tabung4.isEmpty() == true) {
                                item = tabung2.pop();
                                tabung4.push(item);
                            } else {
                                if (tabung2.peek() == tabung4.peek()) {
                                    if (tabung4.isFull() == false) {
                                        item = tabung2.pop();
                                        tabung4.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 5) {
                        if (tabung2.isEmpty() == false) {
                            if (tabung5.isEmpty() == true) {
                                item = tabung2.pop();
                                tabung5.push(item);
                            } else {
                                if (tabung2.peek() == tabung5.peek()) {
                                    if (tabung5.isFull() == false) {
                                        item = tabung2.pop();
                                        tabung5.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    }
                } else if (pindah1 == 3) {
                    if (pindah2 == 1) {
                        if (tabung3.isEmpty() == false) {
                            if (tabung1.isEmpty() == true) {
                                item = tabung3.pop();
                                tabung1.push(item);
                            } else {
                                if (tabung3.peek() == tabung1.peek()) {
                                    if (tabung3.isFull() == false) {
                                        item = tabung3.pop();
                                        tabung1.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 2) {
                        if (tabung3.isEmpty() == false) {
                            if (tabung2.isEmpty() == true) {
                                item = tabung3.pop();
                                tabung2.push(item);
                            } else {
                                if (tabung3.peek() == tabung2.peek()) {
                                    if (tabung2.isFull() == false) {
                                        item = tabung3.pop();
                                        tabung2.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 4) {
                        if (tabung3.isEmpty() == false) {
                            if (tabung4.isEmpty() == true) {
                                item = tabung3.pop();
                                tabung4.push(item);
                            } else {
                                if (tabung3.peek() == tabung4.peek()) {
                                    if (tabung4.isFull() == false) {
                                        item = tabung3.pop();
                                        tabung4.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 5) {
                        if (tabung3.isEmpty() == false) {
                            if (tabung5.isEmpty() == true) {
                                item = tabung3.pop();
                                tabung5.push(item);
                            } else {
                                if (tabung3.peek() == tabung5.peek()) {
                                    if (tabung5.isFull() == false) {
                                        item = tabung3.pop();
                                        tabung5.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    }
                } else if (pindah1 == 4) {
                    if (pindah2 == 1) {
                        if (tabung4.isEmpty() == false) {
                            if (tabung1.isEmpty() == true) {
                                item = tabung4.pop();
                                tabung1.push(item);
                            } else {
                                if (tabung4.peek() == tabung1.peek()) {
                                    if (tabung4.isFull() == false) {
                                        item = tabung4.pop();
                                        tabung1.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 2) {
                        if (tabung4.isEmpty() == false) {
                            if (tabung2.isEmpty() == true) {
                                item = tabung4.pop();
                                tabung2.push(item);
                            } else {
                                if (tabung4.peek() == tabung2.peek()) {
                                    if (tabung2.isFull() == false) {
                                        item = tabung4.pop();
                                        tabung2.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 3) {
                        if (tabung4.isEmpty() == false) {
                            if (tabung3.isEmpty() == true) {
                                item = tabung4.pop();
                                tabung3.push(item);
                            } else {
                                if (tabung4.peek() == tabung3.peek()) {
                                    if (tabung3.isFull() == false) {
                                        item = tabung4.pop();
                                        tabung3.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 5) {
                        if (tabung4.isEmpty() == false) {
                            if (tabung5.isEmpty() == true) {
                                item = tabung4.pop();
                                tabung5.push(item);
                            } else {
                                if (tabung4.peek() == tabung5.peek()) {
                                    if (tabung5.isFull() == false) {
                                        item = tabung4.pop();
                                        tabung5.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    }
                } else if (pindah1 == 5) {
                    if (pindah2 == 1) {
                        if (tabung5.isEmpty() == false) {
                            if (tabung1.isEmpty() == true) {
                                item = tabung5.pop();
                                tabung1.push(item);
                            } else {
                                if (tabung5.peek() == tabung1.peek()) {
                                    if (tabung5.isFull() == false) {
                                        item = tabung5.pop();
                                        tabung1.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 2) {
                        if (tabung5.isEmpty() == false) {
                            if (tabung2.isEmpty() == true) {
                                item = tabung5.pop();
                                tabung2.push(item);
                            } else {
                                if (tabung5.peek() == tabung2.peek()) {
                                    if (tabung2.isFull() == false) {
                                        item = tabung5.pop();
                                        tabung2.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 3) {
                        if (tabung5.isEmpty() == false) {
                            if (tabung3.isEmpty() == true) {
                                item = tabung5.pop();
                                tabung3.push(item);
                            } else {
                                if (tabung5.peek() == tabung3.peek()) {
                                    if (tabung3.isFull() == false) {
                                        item = tabung5.pop();
                                        tabung3.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    } else if (pindah2 == 4) {
                        if (tabung5.isEmpty() == false) {
                            if (tabung4.isEmpty() == true) {
                                item = tabung5.pop();
                                tabung4.push(item);
                            } else {
                                if (tabung5.peek() == tabung4.peek()) {
                                    if (tabung4.isFull() == false) {
                                        item = tabung5.pop();
                                        tabung4.push(item);
                                    } else {
                                        System.err.println("Cannot Move the Item. TUBE IS FULL!!");
                                    }
                                } else {
                                    System.err.println("Cannot Move the Item. ITEM IS MISMATCH!!");
                                }
                            }
                        }
                    }
                } else {
                    System.err.println("Please select EXISTING TUBES (Around 1-5)!");
                }

                if (tabung1.globalArrayList.size()
                        == 4) {
                    if (tabung1.globalArrayList.get(0) == tabung1.globalArrayList.get(1) && tabung1.globalArrayList.get(0) == tabung1.globalArrayList.get(2) && tabung1.globalArrayList.get(0) == tabung1.globalArrayList.get(3)) {
                        if (isCocok1 == false) {
                            skorBertambah++;
                            isCocok1 = true;
                        }
                    }
                }

                if (tabung2.globalArrayList.size()
                        == 4) {
                    if (tabung2.globalArrayList.get(0) == tabung2.globalArrayList.get(1) && tabung2.globalArrayList.get(0) == tabung2.globalArrayList.get(2) && tabung2.globalArrayList.get(0) == tabung2.globalArrayList.get(3)) {
                        if (isCocok2 == false) {
                            skorBertambah++;
                            isCocok2 = true;
                        }
                    }
                }

                if (tabung3.globalArrayList.size()
                        == 4) {
                    if (tabung3.globalArrayList.get(0) == tabung3.globalArrayList.get(1) && tabung3.globalArrayList.get(0) == tabung3.globalArrayList.get(2) && tabung3.globalArrayList.get(0) == tabung3.globalArrayList.get(3)) {
                        if (isCocok3 == false) {
                            skorBertambah++;
                            isCocok3 = true;
                        }
                    }
                }

                if (tabung4.globalArrayList.size()
                        == 4) {
                    if (tabung4.globalArrayList.get(0) == tabung4.globalArrayList.get(1) && tabung4.globalArrayList.get(0) == tabung4.globalArrayList.get(2) && tabung4.globalArrayList.get(0) == tabung4.globalArrayList.get(3)) {
                        if (isCocok4 == false) {
                            skorBertambah++;
                            isCocok4 = true;
                        }
                    }
                }

                if (tabung5.globalArrayList.size()
                        == 4) {
                    if (tabung5.globalArrayList.get(0) == tabung5.globalArrayList.get(1) && tabung5.globalArrayList.get(0) == tabung5.globalArrayList.get(2) && tabung5.globalArrayList.get(0) == tabung5.globalArrayList.get(3)) {
                        if (isCocok5 == false) {
                            skorBertambah++;
                            isCocok5 = true;
                        }
                    }
                }
            }
            System.out.println("\n=================");
            System.out.println("CHEMISTRY SORT-UP");
            System.out.println("=================");
            System.out.println("\nHomogenous Tube : " + skorBertambah);

            for (int i = 3; i > -1; i--) {
                if (tabung1.globalArrayList.size() > i && tabung1.globalArrayList.size() > 0) {
                    System.out.print("| " + tabung1.globalArrayList.get(i) + " | ");
                } else {
                    System.out.print("|   | ");
                }
                if (tabung2.globalArrayList.size() > i && tabung2.globalArrayList.size() > 0) {
                    System.out.print("| " + tabung2.globalArrayList.get(i) + " | ");
                } else {
                    System.out.print("|   | ");
                }
                if (tabung3.globalArrayList.size() > i && tabung3.globalArrayList.size() > 0) {
                    System.out.print("| " + tabung3.globalArrayList.get(i) + " | ");
                } else {
                    System.out.print("|   | ");
                }
                if (tabung4.globalArrayList.size() > i && tabung4.globalArrayList.size() > 0) {
                    System.out.print("| " + tabung4.globalArrayList.get(i) + " | ");
                } else {
                    System.out.print("|   | ");
                }
                if (tabung5.globalArrayList.size() > i && tabung5.globalArrayList.size() > 0) {
                    System.out.print("| " + tabung5.globalArrayList.get(i) + " | ");
                } else {
                    System.out.print("|   | ");
                }
                System.out.println("");
            }
            System.out.println("  1     2     3     4     5");
            System.out.println(">> You Win!!");
            
            System.out.print("\nType p for Play Again : ");
            playOrExit = bermain.next();
//            if (playOrExit.equalsIgnoreCase(q)) {
//                System.out.println("Thank You");
//                System.exit(0);
//            }
        } while (playOrExit.equalsIgnoreCase(p));
        run();
    }
}
