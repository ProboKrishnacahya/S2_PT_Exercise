package GeometryCoveredMaster;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class Rectangle implements Shape {

    double p = 0;
    double l = 0;

//getter
    public double getP() {
        return p;
    }

    public double getL() {
        return l;
    }

//setter
    public void setP(double p) {
        this.p = p;
    }

    public void setL(double l) {
        this.l = l;
    }

    @Override
    public double luas() {
        double luas = p * l;
        return luas;
    }

    @Override
    public double keliling() {
        double keliling = 2 * (p + l);
        return keliling;
    }

    @Override
    public void setR(int radius) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void getR() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
