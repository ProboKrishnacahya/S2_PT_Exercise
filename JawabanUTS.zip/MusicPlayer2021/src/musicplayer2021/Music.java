/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musicplayer2021;

/**
 *
 * @author caeciliacitra
 */
public class Music {
    protected String singer, title, genre;
    protected int seconds;
    
    public String getSinger(){
        return singer;
    }
    public String getTitle(){
        return title;
    }
    public String getGenre(){
        return genre;
    }
    public int getSeconds(){
        return seconds;
    }
    
    public Music(String singer, String title, String genre, int seconds){
        this.singer = singer;
        this.title = title;
        this.genre = genre;
        this.seconds = seconds;
    }
    
    public void play(){
        System.out.println(title + " - "+ singer);
        System.out.println("Genre : " + genre + "("+ seconds +  " secs)");
    }
    
}
