package GeometryCoveredMaster;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public abstract class Circle implements Shape {

    double r = 0;

//getter
    public double getR() {
        return r;
    }

//setter
    public void setR(double r) {
        this.r = r;
    }

    @Override
    public double luas() {
        double luas = 3.14 * r * r;
        return luas;
    }

    @Override
    public double keliling() {
        double keliling = 2 * 3.14 * r;
        return keliling;
    }

    @Override
    public void setR(int radius) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
