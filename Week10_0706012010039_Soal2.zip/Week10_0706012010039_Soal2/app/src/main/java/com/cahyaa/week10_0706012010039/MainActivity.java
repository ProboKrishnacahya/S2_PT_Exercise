package com.cahyaa.week10_0706012010039;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageView bgProfile, iconProfile, blue, red, green;
    private RadioGroup radioGroup;
    private RadioButton radioButton_penguin, radioButton_dog, radioButton_cat;
    private Button main_button_saveProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bgProfile = findViewById(R.id.bgProfile);
        iconProfile = findViewById(R.id.iconProfile);
        blue = findViewById(R.id.blue);
        red = findViewById(R.id.red);
        green = findViewById(R.id.green);
        radioGroup = findViewById(R.id.radioGroup);
        radioButton_penguin = findViewById(R.id.radioButton_penguin);
        radioButton_dog = findViewById(R.id.radioButton_dog);
        radioButton_cat = findViewById(R.id.radioButton_cat);
        main_button_saveProfile = findViewById(R.id.main_button_saveProfile);

        radioButton_penguin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconProfile.setImageResource(R.drawable.penguin);
            }
        });

        radioButton_dog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconProfile.setImageResource(R.drawable.dog);
            }
        });

        radioButton_cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconProfile.setImageResource(R.drawable.cat);
            }
        });

        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bgProfile.setImageResource(R.drawable.blue);
            }
        });

        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bgProfile.setImageResource(R.drawable.red);
            }
        });

        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bgProfile.setImageResource(R.drawable.green);
            }
        });

        main_button_saveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selected;

                selected = radioGroup.getCheckedRadioButtonId();
                if(selected < 0){
                    Toast.makeText(getApplicationContext(), "Please Choose Your Icon and Background.", Toast.LENGTH_SHORT).show();
                } else {
//                    profilePicture(selected);
                Toast.makeText(getApplicationContext(), "Profile Updated!", Toast.LENGTH_SHORT).show();
            }
        }
    });
}
}