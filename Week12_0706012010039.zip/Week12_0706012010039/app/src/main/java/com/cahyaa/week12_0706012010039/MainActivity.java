package com.cahyaa.week12_0706012010039;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.regex.Pattern;
import model.Anime;

public class MainActivity extends AppCompatActivity {

    private RecyclerView main_recyclerView;
    private ArrayList<Anime> listAnime;
    private TextView main_textView;
    private AnimeRVAdapter adapter;
    private FloatingActionButton main_FAB_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        setupRecyclerView();
        addDummyData();
        setListener();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        main_textView = findViewById(R.id.main_textView);

        if (requestCode == 1) {
            if (resultCode == 200) {
                Anime barangBaru = data.getParcelableExtra("barangBaru");
                listAnime.add(barangBaru);
                adapter.notifyDataSetChanged();
            }
        }
        if (!listAnime.isEmpty()) {
            main_textView.setVisibility(View.GONE);
        }
    }

    private void setListener() {
        main_FAB_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), add_collection.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    private void addDummyData() {
//        listAnime.add(new Anime("Kimetsu no Yaiba","Koyoharu Gotouge", 12));
//        listAnime.add(new Anime("Owari no Seraph","Takaya Kagami",20));
//        listAnime.add(new Anime("Shokugeki no Soma","Yuto Shukuda",24));
//        listAnime.add(new Anime("Tokyo Ghoul S4","Sul Ishida",50));
//        listAnime.add(new Anime("Naruto Shippuden","Narto",70));
//        listAnime.add(new Anime("Doraemon","Dora",1));
        adapter.notifyDataSetChanged();
    }

    private void setupRecyclerView() {
        RecyclerView.LayoutManager manager = new LinearLayoutManager(getBaseContext());
        main_recyclerView.setLayoutManager(manager);
        main_recyclerView.setAdapter(adapter);
    }

    private void initView() {
        main_recyclerView = findViewById(R.id.main_recyclerView);
        listAnime = new ArrayList<Anime>();
        adapter = new AnimeRVAdapter(listAnime);
        main_FAB_add = findViewById(R.id.main_FAB_add);
    }

        private static final int TIME_INTERVAL = 2000;
        private long doubleClick;

        @Override
        public void onBackPressed ()
        {
            if (doubleClick + TIME_INTERVAL > System.currentTimeMillis()) {
                super.onBackPressed();
                return;
            } else {
                Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT).show();
            }
            doubleClick = System.currentTimeMillis();
        }
    }