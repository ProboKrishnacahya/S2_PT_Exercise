package com.cahyaa.week12_0706012010039;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputLayout;
import java.util.regex.Pattern;
import model.Anime;

public class add_collection extends AppCompatActivity {

    private TextInputLayout add_textInputLayout_title, add_textInputLayout_episode, add_textInputLayout_penulis;
    private Button add_button;
    private ImageView add_imageView_back;
    private Boolean duaPuluhKarakter;
    private ProgressDialog add_progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_collection);
        initView();
        setListener();
    }

    private void setListener() {
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = add_textInputLayout_title.getEditText().getText().toString().trim();
                String penulis = add_textInputLayout_penulis.getEditText().getText().toString().trim();
                int jumlah = Integer.parseInt(add_textInputLayout_episode.getEditText().getText().toString().trim());
                Anime temp = new Anime(nama, penulis, jumlah);

                Intent intent = new Intent();
                intent.putExtra("barangBaru", temp);
                setResult(200, intent);
                finish();
            }
        });
    }

    private void initView() {
        add_textInputLayout_title = findViewById(R.id.add_textInputLayout_title);
        add_textInputLayout_episode = findViewById(R.id.add_textInputLayout_episode);
        add_textInputLayout_penulis = findViewById(R.id.add_textInputLayout_penulis);
        add_button = findViewById(R.id.add_button);
        add_imageView_back = findViewById(R.id.add_imageView_back);
        add_imageView_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        add_textInputLayout_title.getEditText().addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String title = add_textInputLayout_title.getEditText().getText().toString().trim();

                Pattern TITLE_PATTERN = Pattern.compile("[a-zA-Z0-9\\!\\@\\#\\$]{0,20}");

                if (title.length() < 0 || title.length() > 20) {
                    add_textInputLayout_title.setError("Hanya menerima maksimal 20 karakter");
                    duaPuluhKarakter = false;
                } else {
                    add_textInputLayout_title.setError("");
                    duaPuluhKarakter = true;
                }
                add_button.setEnabled(!title.isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

            add_button = (Button) findViewById(R.id.add_button);
    }
}

//        public void save (View view){
//            add_progressBar = new ProgressDialog(this);
//            add_progressBar.setMessage("Loading...");
//            add_progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
//            add_progressBar.setIndeterminate(true);
//            add_progressBar.setProgress(0);
//            add_progressBar.show();
//
//            final int totalProgressTime = 100;
//            final Thread t = new Thread() {
//                @Override
//                public void run() {
//                    int jumpTime = 0;
//                    while (jumpTime < totalProgressTime) {
//                        try {
//                            sleep(200);
//                        } catch (InterruptedException e) {
//                            // TODO Auto-generated catch block
//                            e.printStackTrace();
//                        }
//                    }
//                }
//            };
//            t.start();
//        }

//    String title = "";
//    String penulis = "";
//    int episode = 0;
//
//add_button.setOnClickListener(new View.OnClickListener() {
//        if(duaPuluhKarakter == true) {
//        Anime temp = new Anime(title, penulis, episode);
//        Intent intent = new Intent();
//        intent.putExtra("AnimeBaru", temp);
//        setResult(200, intent);
//        finish();
//    } else {
//        add_textInputLayout_title.setError("Hanya menerima maksimal 20 karakter");
//    }
//}
//}

//    add_textInputLayout_title.addTextChangedListener(new void TextWatcher() {

//        @Override
//        public void beforeTextChanged (CharSequence s,int start, int count, int after){
//
//        }

//        @Override
//        public void onTextChanged (CharSequence s,int start, int count, int after){
//
//        }

//        @Override
//        public void afterTextChanged (Editable s){
//            underTwentyOneChar();
//        }
//    }

//    private void underTwentyOneChar()
//    {
//        String inputText = add_textInputLayout_title.getEditText().toString();
//        if(inputText.length() > 20) {
//            add_button.setEnabled(true);
//        } else {
//            add_button.setEnabled(false);
//        }
//    }
//}

//        add_button.setOnClickListener(new View.OnClickListener() {
//        add_textInputLayout_title.getEditText().addTextChangedListener(new TextWatcher() {
//        @Override
//        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//
//        }
//
//        @Override
//        public void onTextChanged(CharSequence s, int start, int before, int count) {
//            String title = add_textInputLayout_title.getEditText().getText().toString().trim();
//
//            if (title.isEmpty()) {
//                add_textInputLayout_title.setError("Silakan isi kolom Anime Title");
//                duaPuluhKarakter = false;
//                } else {
//                    if (title.length() > 20) {
//                    add_textInputLayout_title.setError("Hanya menerima maksimal 20 karakter");
//                    duaPuluhKarakter = false;
//                        } else {
//                        add_textInputLayout_title.setError("");
//                        duaPuluhKarakter = true;
//                        }
//                    }
//                }
//
//        @Override
//        public void afterTextChanged(Editable s) {
//
//            }
//        });
//    }