package GeometryCoveredMaster;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class Main {

    public static void main(String[] args) {

        Menu sistem = new Menu();
        sistem.doYourJob();
    }
}
