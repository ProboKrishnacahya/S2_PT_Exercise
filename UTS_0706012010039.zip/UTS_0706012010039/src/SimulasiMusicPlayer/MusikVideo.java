package SimulasiMusicPlayer;

import java.util.ArrayList;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class MusikVideo {

    private String Penyanyi;
    private String Judul;
    private String Genre;
    private int Durasi;
    private int PanjangVideo;
    private int LebarVideo;
    
    private ArrayList<MusikVideo> library = new ArrayList<MusikVideo>();

    /**
     * @return the Penyanyi
     */
    public String getPenyanyi() {
        return Penyanyi;
    }

    /**
     * @param Penyanyi the Penyanyi to set
     */
    public void setPenyanyi(String Penyanyi) {
        this.Penyanyi = Penyanyi;
    }

    /**
     * @return the Judul
     */
    public String getJudul() {
        return Judul;
    }

    /**
     * @param Judul the Judul to set
     */
    public void setJudul(String Judul) {
        this.Judul = Judul;
    }

    /**
     * @return the Genre
     */
    public String getGenre() {
        return Genre;
    }

    /**
     * @param Genre the Genre to set
     */
    public void setGenre(String Genre) {
        this.Genre = Genre;
    }

    /**
     * @return the Durasi
     */
    public int getDurasi() {
        return Durasi;
    }

    /**
     * @param Durasi the Durasi to set
     */
    public void setDurasi(int Durasi) {
        this.Durasi = Durasi;
    }

    /**
     * @return the PanjangVideo
     */
    public int getPanjangVideo() {
        return PanjangVideo;
    }

    /**
     * @param PanjangVideo the PanjangVideo to set
     */
    public void setPanjangVideo(int PanjangVideo) {
        this.PanjangVideo = PanjangVideo;
    }

    /**
     * @return the LebarVideo
     */
    public int getLebarVideo() {
        return LebarVideo;
    }

    /**
     * @param LebarVideo the LebarVideo to set
     */
    public void setLebarVideo(int LebarVideo) {
        this.LebarVideo = LebarVideo;
    }

    void add(MusikVideo library) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
