package GeometryCoveredMaster;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class Menu {

    private ArrayList<Shape> shape = new ArrayList<Shape>();

    public void doYourJob() {

        int random = (int) (Math.random() * (100 - 0 + 1));
        int life = 3;
        int level = 1;
        int score = 0;
        int area = 0;
        int max = 3;
        int pilih = 0;

        while (pilih < 4) {
            Scanner s = new Scanner(System.in);
            System.out.println("\n++++++++++++++++++++++++++++");
            System.out.println("+ GEOMETERY COVERED MASTER +");
            System.out.println("++++++++++++++++++++++++++++");
            System.out.println("\nLevel : " + level + " | Life : " + life + " | Score : " + score);
            System.out.println("=================================");
            System.out.println("\nTarget Area Covered : " + random);
            System.out.println("Shape Collections : " + shape.size() + " (max:" + max + ")");
            System.out.println("1) Add Collection | 2) Remove Collection | 3) Hit | 4) End Game");
            System.out.print("Choose : ");
            pilih = s.nextInt();

            int ubah = 0;
            int hit = 1;
            String confirm = "";
            String Y = "";

//            switch (pilih) {
//                case 1:
//                    addCollection();
//                    break;
//            }
            int collection = 1;

            switch (pilih) {
                case 1:
                    System.out.println("== New shape ==");
                    System.out.println("1. Circle");
                    System.out.println("2. Rectangle");
                    System.out.println("3. Right Triangle");
                    System.out.println("Choose");
                    int select = s.nextInt();
                    switch (select) {
                        case 1:
                            Shape Circle;
                            Circle = new Rectangle();
                            System.out.print("Circle radius : ");
                            int radius = s.nextInt();
                            Circle.setR(radius);
                            shape.add(Circle);
                            Circle.getR();
                            break;
                        case 2:
                            Shape Rectangle;
                            Rectangle = new Rectangle();
                            System.out.print("Rectangle's Width : ");
                            int width = s.nextInt();
                            Rectangle.setWidth(width);
                            System.out.print("Rectangle's Length : ");
                            int P = s.nextInt();
                            Rectangle.setP(P);
                            shape.add(Rectangle);
                            Rectangle.getLuasRec();
                            break;
                        case 3:
                            Shape RightTriangle;
                            RightTriangle = new Rectangle();
                            System.out.print("Triangle's Width : ");
                            int A = s.nextInt();
                            RightTriangle.setA(A);
                            System.out.print("Triangle's Height : ");
                            int T = s.nextInt();
                            RightTriangle.setT(T);
                    }
                    break;
                case 2:
                    for (int i = 0; i < shape.size(); i++) {
                        Shape sh = shape.get(i);
                        System.out.println((i + 1) + ". " + sh.getName() + "{w=" + sh.getWidth() + " | " + "h=" + sh.getLength() + ")");
                    }
                    System.out.println("Remove : ");
                    int chose = s.nextInt() - 1;
                    Shape bangun;
                    bangun = shape.get(chose);
                    shape.remove(bangun);
                    break;
                case 3:
                    System.out.println("== HIT !!");
                    System.out.println("LEVEL Up !!");
                    break;
                case 4:
                    System.exit(0);
                    System.out.println("\nThank You :) ");
                               }
        }
    }
}
