package GeometryCoveredMaster;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class RightTriangle implements Shape {

    double a = 0;
    double t = 0;
    double s = 0;

//getter
    public double getA() {
        return a;
    }

    public double getT() {
        return t;
    }

    public double getS() {
        return s;
    }

//setter
    public void setA(double a) {
        this.a = a;
    }

    public void setL(double t) {
        this.t = t;
    }

    public void setS(double s) {
        this.s = s;
    }

    @Override
    public double luas() {
        double luas = 1 / 2 * (a * t);
        return luas;
    }

    @Override
    public double keliling() {
        double keliling = s + s + s;
        return keliling;
    }

    @Override
    public void setR(int radius) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void getR() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
