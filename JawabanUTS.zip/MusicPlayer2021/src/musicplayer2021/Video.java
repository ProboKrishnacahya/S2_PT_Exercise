/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musicplayer2021;

/**
 *
 * @author caeciliacitra
 */
public class Video extends Music{
    private int length, width;
    
    public Video(String singer, String title, String genre, int seconds, int length, int width) {
        super(singer, title, genre, seconds);
        this.length = length;
        this.width = width;
    }

    
    
    public void play(){
        super.play();
        int l = length/64;
        int w = width/64;
        System.out.println(l + ", " + w);
        for(int i=0; i<w; i++){
            for(int j = 0; j<l; j++){
                if(i==0 || i== w-1){
                    System.out.print("+ ");
                }else{
                    if(j==0 || j==l-1){
                        System.out.print("+ ");
                    }else{
                        System.out.print("  ");
                    }
                }
            }
            System.out.println("");
        }
    }
    
    
}
