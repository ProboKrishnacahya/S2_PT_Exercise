package com.cahyaa.week12_0706012010039;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import model.Anime;

public class AnimeRVAdapter extends RecyclerView.Adapter<AnimeRVAdapter.AnimeViewHolder> {

    private ArrayList<Anime> ListAnime;

    public AnimeRVAdapter(ArrayList<Anime> listAnime) {
        this.ListAnime = listAnime;
    }

    @NonNull
    @Override
    public AnimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view =layoutInflater.inflate(R.layout.display_collection, parent, false);
        return new AnimeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeViewHolder holder, int position) {
        holder.display_textView_title.setText(ListAnime.get(position).getNama());
        holder.display_textView_episode.setText(String.valueOf(ListAnime.get(position).getJumlah()));
        holder.display_textView_penulis.setText(ListAnime.get(position).getPenulis());
    }

    @Override
    public int getItemCount() {
        return ListAnime.size();
    }

    public class AnimeViewHolder extends RecyclerView.ViewHolder {

        private TextView display_textView_title, display_textView_episode, display_textView_penulis;
        private ImageView display_imageView_item;

        public AnimeViewHolder(@NonNull View itemView) {
            super(itemView);
            display_textView_title = itemView.findViewById(R.id.display_textView_title);
            display_textView_episode = itemView.findViewById(R.id.display_textView_episode);
            display_textView_penulis = itemView.findViewById(R.id.display_textView_penulis);
            display_imageView_item = itemView.findViewById(R.id.display_imageView_item);
        }
    }
}
