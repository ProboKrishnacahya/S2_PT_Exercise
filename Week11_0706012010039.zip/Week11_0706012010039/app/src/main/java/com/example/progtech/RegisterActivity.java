package com.example.progtech;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.material.textfield.TextInputLayout;

import model.User;

public class RegisterActivity extends AppCompatActivity {

    private TextInputLayout register_textInput_email, register_textInput_nama, register_textInput_password;
    private Button Register_button_transparent, Register_button_register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        register_textInput_email = findViewById(R.id.register_textInput_email);
        register_textInput_nama = findViewById(R.id.register_textInput_nama);
        register_textInput_password = findViewById(R.id.register_textInput_password);
        Register_button_transparent = findViewById(R.id.Register_button_transparent);
        Register_button_register = findViewById(R.id.Register_button_register);

        Register_button_transparent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        Register_button_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = register_textInput_email.getEditText().getText().toString().trim();
                String nama = register_textInput_nama.getEditText().getText().toString().trim();
                String password = register_textInput_password.getEditText().getText().toString().trim();
                if (email.isEmpty()) {
                    register_textInput_email.setError("Please fill the email column");
//                    Register_button_register.setEnabled(false);
                } else {
                    register_textInput_email.setError("");
//                    Register_button_register.setEnabled(true);

                }if (nama.isEmpty()) {
                    register_textInput_nama.setError("Please fill the name column");
//                    Register_button_register.setEnabled(false);
                } else {
                    register_textInput_nama.setError("");
//                    Register_button_register.setEnabled(true);
                }

                if (password.isEmpty()) {
                    register_textInput_password.setError("Please fill the password column");
//                    Register_button_register.setEnabled(false);
                } else {
                    register_textInput_password.setError("");
//                    Register_button_register.setEnabled(true);
                }

                if (!email.isEmpty() && !nama.isEmpty() && !password.isEmpty()){
                    Intent intent = new Intent(getBaseContext(), HomeActivity.class);
                    User user = new User(email, nama, password);
                    intent.putExtra("IDuser", user);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }
            }
        });
    }
}