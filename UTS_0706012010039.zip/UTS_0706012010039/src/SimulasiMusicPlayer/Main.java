package SimulasiMusicPlayer;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class Main {

    public static void main(String[] args) {

        MusicPlayer lagu = new MusicPlayer();
        lagu.doYourJob();
    }
}
