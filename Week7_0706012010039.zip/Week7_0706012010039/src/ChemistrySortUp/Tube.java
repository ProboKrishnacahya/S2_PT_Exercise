package ChemistrySortUp;

import java.util.ArrayList;

public class Tube {

    public ArrayList globalArrayList = new ArrayList();
    private int top = -1;

    public void push(Object item) {
        globalArrayList.add(item);
        top++;
    }

    public Object peek() {
        if (top > -1) {
            return globalArrayList.get(top);
        } else {
            return "Tube is Empty";
        }
    }

    public Object pop() {
        Object temp = globalArrayList.remove(top);
        top--;
        return temp;
    }

    public boolean isEmpty() {
        return (top == -1);
    }

    public boolean isFull() {
        return (top == 3);
    }
}
