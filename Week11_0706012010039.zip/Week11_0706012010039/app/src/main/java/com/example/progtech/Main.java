package com.example.progtech;

import android.app.Activity;

public class Main extends Activity {
}
