package SimulasiMusicPlayer;

import java.util.ArrayList;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class MusikBiasa {

    private String Penyanyi;
    private String Judul;
    private String Genre;
    private int Durasi;
    
    private ArrayList<MusikBiasa> library = new ArrayList<MusikBiasa>();

    /**
     * @return the Penyanyi
     */
    public String getPenyanyi() {
        return Penyanyi;
    }

    /**
     * @param Penyanyi the Penyanyi to set
     */
    public void setPenyanyi(String Penyanyi) {
        this.Penyanyi = Penyanyi;
    }

    /**
     * @return the Judul
     */
    public String getJudul() {
        return Judul;
    }

    /**
     * @param Judul the Judul to set
     */
    public void setJudul(String Judul) {
        this.Judul = Judul;
    }

    /**
     * @return the Genre
     */
    public String getGenre() {
        return Genre;
    }

    /**
     * @param Genre the Genre to set
     */
    public void setGenre(String Genre) {
        this.Genre = Genre;
    }

    /**
     * @return the Durasi
     */
    public int getDurasi() {
        return Durasi;
    }

    /**
     * @param Durasi the Durasi to set
     */
    public void setDurasi(int Durasi) {
        this.Durasi = Durasi;
    }

    void add(MusikBiasa library) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
