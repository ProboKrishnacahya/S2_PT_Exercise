/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musicplayer2021;

import java.util.ArrayList;

/**
 *
 * @author caeciliacitra
 */
public class Playlist {
    private String name;
    private int duration;
    private ArrayList<Music> musics = new ArrayList<Music>();
    private Music currentMusic;
    
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name= name;
    }
    public int getDuration(){
        return duration;
    }
    public void addMusic(Music m){
        musics.add(m);
        duration += m.getSeconds();
    }
    public void removeMuisc(int id){
        duration -= musics.get(id).getSeconds();
        musics.remove(id);
        
    }
    public void chooseMusic(int id){
        currentMusic = musics.get(id);
                
    }
    public int getCollectionSize(){
        return musics.size();
    }
    
    public void playMusic(){
        currentMusic.play();
    }
    public Music getMusic(int id){
        return musics.get(id);
    }
    public void nextMusic(boolean random, boolean loop){
        
        int id=-1;
        if(!random)
            id =musics.indexOf(currentMusic) +1;
        else{
            id = (int)(Math.random()*musics.size());
        }
        
        if(id != musics.size()){
            currentMusic = musics.get(id);
            
        }else{
            if(!loop)
                System.out.println("You are at the end of the list");
            else 
                currentMusic = musics.get(0);
        }
    }
    public void prevMusic(boolean random, boolean loop){
        int id=-1;
        if(!random)
            id =musics.indexOf(currentMusic) -1;
        else{
            id = (int)(Math.random()*musics.size());
        }
        if(id >= 0){
            currentMusic = musics.get(id);
            
        }else{
            if (!loop)
                System.out.println("You are at the beginning of the list");
            else
                currentMusic = musics.get(musics.size()-1);
        }
    }
    
    public void showMusics(){
        for(int i=0; i< musics.size(); i++){
            Music m = musics.get(i);
            System.out.println((i+1)+ ". "+ m.getTitle() + " ("+ m.getSinger()+")");
        }
    }
    
    
    
    
}
