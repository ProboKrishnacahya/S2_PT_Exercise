package SimulasiMusicPlayer;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class MusicPlayer {

    ArrayList<MusikBiasa> availMB = new ArrayList<MusikBiasa>();
    ArrayList<MusikVideo> availMV = new ArrayList<MusikVideo>();
    ArrayList<MusicPlayer> library = new ArrayList<MusicPlayer>();

    public void library() {
        MusikBiasa mb = new MusikBiasa();
        mb.setPenyanyi("BTS");
        mb.setJudul("Dynamite");
        mb.setGenre("K-Pop");
        mb.setDurasi(200);
        availMB.add(mb);
        mb = new MusikBiasa();
        mb.setPenyanyi("Afgan");
        mb.setJudul("Sudah");
        mb.setGenre("Pop");
        mb.setDurasi(195);
        availMB.add(mb);
        mb = new MusikBiasa();
        mb.setPenyanyi("Pamungkas");
        mb.setJudul("To The Bone");
        mb.setGenre("Pop");
        mb.setDurasi(200);
        availMB.add(mb);
        mb = new MusikBiasa();
        mb.setPenyanyi("Ardhito Pramono");
        mb.setJudul("Bitterlove");
        mb.setGenre("Pop Jazz");
        mb.setDurasi(216);
        availMB.add(mb);
        mb = new MusikBiasa();
        mb.setPenyanyi("BTS");
        mb.setJudul("DNA");
        mb.setGenre("K-Pop");
        mb.setDurasi(256);
        availMB.add(mb);
        mb = new MusikBiasa();
        mb.setPenyanyi("Didi Kempot");
        mb.setJudul("Pamer Bojo");
        mb.setGenre("Campursari");
        mb.setDurasi(240);
        availMB.add(mb);
        mb = new MusikBiasa();
        mb.setPenyanyi("Queen");
        mb.setJudul("Bohemian Rhapsody");
        mb.setGenre("Rock");
        mb.setDurasi(389);
        availMB.add(mb);

        MusikVideo mv = new MusikVideo();
        mv.setPenyanyi("Pentatonix");
        mb.setJudul("Mary Did You Know");
        mb.setGenre("Pop");
        mv.setDurasi(220);
        mv.setPanjangVideo(1024);
        mv.setLebarVideo(960);
        availMV.add(mv);
        mv = new MusikVideo();
        mv.setPenyanyi("Blackpink");
        mb.setJudul("How +You Like");
        mb.setGenre("K-Pop");
        mv.setDurasi(184);
        mv.setPanjangVideo(1024);
        mv.setLebarVideo(960);
        availMV.add(mv);
        mv = new MusikVideo();
        mv.setPenyanyi("Justin Bieber feat. Arianne Grande");
        mb.setJudul("Stuck With You");
        mb.setGenre("Pop");
        mv.setDurasi(197);
        mv.setPanjangVideo(640);
        mv.setLebarVideo(480);
        availMV.add(mv);
    }

    public void doYourJob() {

        Scanner s = new Scanner(System.in);

        int choose = 0;
        int jenis;
        long harga;
        String nama;

        while (choose < 4) {
            System.out.println("\n=======================");
            System.out.println("WELCOME TO MUSIC PLAYER");
            System.out.println("=======================\n");
            System.out.println("Menu");
            System.out.println("1. Play Music");
            System.out.println("2. Manage Playlist");
            System.out.println("3. Add New Music to Library");
            System.out.println("4. Exit");
            System.out.print("Choose: ");
            choose = s.nextInt();
            int pilihan = -1;
            String play = null;
            switch (choose) {
                case 1:
                    while (pilihan != 0) {
                        System.out.println("\n=== PLAY MUSIC FROM ===");
                        System.out.println("1. Library");
                        System.out.println("2. Back");
                        System.out.print("Choose : ");
                        Scanner scan1 = new Scanner(System.in);
                        pilihan = scan1.nextInt();
                        switch (pilihan) {
                            case 1:
                                System.out.println("Randomize Musics");
                                YesNo();
                                System.out.println("Loop Playlist");
                                YesNo();
                                System.out.println("****************");
                                library();
                                System.out.println("****************");
                                System.out.print("Choose --> Prev (<) | Next (>) | Quit (q) : ");
                                play = scan1.next();
                                if (play.equals("q")) {
                                    System.out.println("\n=== PLAY MUSIC FROM ===");
                                    System.out.println("1. Library");
                                    System.out.println("2. Back");
                                    System.out.print("Choose : ");
                                } else if (play.equals("<")) {
                                    System.out.println("");
                                } else if (play.equals(">")) {
                                    System.out.println("");
                                } else {
                                    System.err.println("Input tidak ditemukan!");
                                }
                                break;
                            case 2:
                                System.out.println("\n=======================");
                                System.out.println("WELCOME TO MUSIC PLAYER");
                                System.out.println("=======================\n");
                                System.out.println("Menu");
                                System.out.println("1. Play Music");
                                System.out.println("2. Manage Playlist");
                                System.out.println("3. Add New Music to Library");
                                System.out.println("4. Exit");
                                System.out.print("Choose: ");
                                choose = s.nextInt();
                                break;
                        }
                    }
                case 2:
                    while (pilihan != 0) {
                        System.out.println("=== MANAGE PLAYLIST ===");
                        System.out.println("1. New Playlist");
                        System.out.println("2. Back");
                        System.out.print("Choose : ");
                        Scanner scan2 = new Scanner(System.in);
                        pilihan = scan2.nextInt();
                        switch (pilihan) {
                            case 1:
                                System.out.print("Playlist Name : ");
                                String playlist = scan2.next();
                                System.out.println("New Playlist is added.");
                                System.out.println("To do --> 1) Add Music | 2) Remove Music | 3) Back");
                                playlist = scan2.next();
                                break;
                            case 2:
                                System.out.println("\n=======================");
                                System.out.println("WELCOME TO MUSIC PLAYER");
                                System.out.println("=======================\n");
                                System.out.println("Menu");
                                System.out.println("1. Play Music");
                                System.out.println("2. Manage Playlist");
                                System.out.println("3. Add New Music to Library");
                                System.out.println("4. Exit");
                                System.out.print("Choose: ");
                                choose = s.nextInt();
                                break;
                        }
                    }
                case 3:
                    System.out.println("=== ADD NEW MUSIC TO LIBRARY ===");
                    System.out.print("Type --> 1. Audio | 2. Video : ");
                    int baru = 0;
                    Scanner scan3 = new Scanner(System.in);
                    baru = scan3.nextInt();
                    while (baru == 1) {
                        MusikBiasa library = new MusikBiasa();
                        System.out.print("Singer : ");
                        String Penyanyi = scan3.next();
                        library.setPenyanyi(Penyanyi);
                        System.out.print("Title : ");
                        String Judul = scan3.next();
                        library.setJudul(Judul);
                        System.out.print("Genre : ");
                        String Genre = scan3.next();
                        library.setGenre(Genre);
                        System.out.print("Duration in Seconds : ");
                        int Durasi = scan3.nextInt();
                        library.setDurasi(Durasi);
                        library.add(library);
                        System.out.println("Music is added to Library.");
                        System.out.println("Add More? ");
                        YesNo();
                    }
                    while (baru == 2) {
                        MusikVideo library = new MusikVideo();
                        System.out.print("Singer : ");
                        String Penyanyi = scan3.next();
                        library.setPenyanyi(Penyanyi);
                        System.out.print("Title : ");
                        String Judul = scan3.next();
                        library.setJudul(Judul);
                        System.out.print("Genre : ");
                        String Genre = scan3.next();
                        library.setGenre(Genre);
                        System.out.print("Duration in Seconds : ");
                        int Durasi = scan3.nextInt();
                        library.setDurasi(Durasi);
                        System.out.print("Video Dimension (Length) : ");
                        int PanjangVideo = scan3.nextInt();
                        library.setPanjangVideo(PanjangVideo);
                        System.out.print("Video Dimension (Width) : ");
                        int LebarVideo = scan3.nextInt();
                        library.setLebarVideo(LebarVideo);
                        library.add(library);
                        System.out.println("Music is added to Library.");
                        System.out.println("Add More? ");
                        YesNo();
                        break;
                    }
                case 4:
                    System.out.println("\nThank You\n");
                    System.exit(0);
            }
        }
    }

    public void YesNo() {
        String YN;
        do {
            System.out.print("(Y/N)? ");
            Scanner input = new Scanner(System.in);
            YN = input.next();
            switch (YN) {
                case "y":
                case "Y":
                    break;
                case "n":
                case "N":
                    break;
            }
        } while (YN.equals("y") || YN.equals("Y"));
    }
}
