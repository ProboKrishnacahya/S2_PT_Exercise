package ChemistrySortUp;

/**
 *
 * @author Probo Krishnacahya (0706012010039)
 */
public class Main {

    public static void main(String[] args) {
        Game game = new Game();
        game.run();
    }
}
