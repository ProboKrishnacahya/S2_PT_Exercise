package com.cahyaa.week10_0706012010039;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;

public class mobile_calculator extends AppCompatActivity {

//    private EditText editTextNumber;
    private TextView hasil;
    private Button main_button_1;
    private Button main_button_2;
    private Button main_button_3;
    private Button main_button_tambah;
    private Button main_button_4;
    private Button main_button_5;
    private Button main_button_6;
    private Button main_button_kurang;
    private Button main_button_7;
    private Button main_button_8;
    private Button main_button_9;
    private Button main_button_kali;
    private Button main_button_c;
    private Button main_button_0;
    private Button main_button_samaDengan;
    private Button main_button_bagi;

    double input1, input2;
    //    String operasi;
    boolean tambah, kurang, kali, bagi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mobile_calculator);

//        editTextNumber = (EditText) findViewById(R.id.editTextNumber);
        hasil = (TextView) findViewById(R.id.hasil);
        main_button_1 = (Button) findViewById(R.id.main_button_1);
        main_button_2 = (Button) findViewById(R.id.main_button_2);
        main_button_3 = (Button) findViewById(R.id.main_button_3);
        main_button_tambah = (Button) findViewById(R.id.main_button_tambah);
        main_button_4 = (Button) findViewById(R.id.main_button_4);
        main_button_5 = (Button) findViewById(R.id.main_button_5);
        main_button_6 = (Button) findViewById(R.id.main_button_6);
        main_button_kurang = (Button) findViewById(R.id.main_button_kurang);
        main_button_7 = (Button) findViewById(R.id.main_button_7);
        main_button_8 = (Button) findViewById(R.id.main_button_8);
        main_button_9 = (Button) findViewById(R.id.main_button_9);
        main_button_kali = (Button) findViewById(R.id.main_button_kali);
        main_button_c = (Button) findViewById(R.id.main_button_c);
        main_button_0 = (Button) findViewById(R.id.main_button_0);
        main_button_samaDengan = (Button) findViewById(R.id.main_button_samaDengan);
        main_button_bagi = (Button) findViewById(R.id.main_button_bagi);

        main_button_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"1");
            }
        });
        main_button_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"2");
            }
        });
        main_button_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"3");
            }
        });
        main_button_tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasil.getText().length() == 0){
                    hasil.setText("");
                } else {
                    input1 = Double.parseDouble(hasil.getText() + "");
                    tambah = true;
                    hasil.setText(null);
                }
            }
        });
        main_button_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"4");
            }
        });
        main_button_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"5");
            }
        });
        main_button_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"6");
            }
        });
        main_button_kurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasil.getText().length() == 0){
                    hasil.setText("");
                } else {
                    input1 = Double.parseDouble(hasil.getText() + "");
                    kurang = true;
                    hasil.setText(null);
                }
            }
        });
        main_button_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"7");
            }
        });
        main_button_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"8");
            }
        });
        main_button_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"9");
            }
        });
        main_button_kali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasil.getText().length() == 0){
                    hasil.setText("");
                } else {
                    input1 = Double.parseDouble(hasil.getText() + "");
                    kali = true;
                    hasil.setText(null);
                }
            }
        });
        main_button_c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText("");
            }
        });
        main_button_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasil.setText(hasil.getText()+"0");
            }
        });
        main_button_samaDengan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(hasil.getText().length() == 0){
                    hasil.setText("");
                } else {
                    input2 = Double.parseDouble(hasil.getText() + "");

                    if (tambah == true) {
                        hasil.setText((double) input1 + (double) input2 + "");
                        tambah = false;
                    }
                    if (kurang == true) {
                        hasil.setText((double) input1 - (double) input2 + "");
                        kurang = false;
                    }
                    if (kali == true) {
                        hasil.setText((double) input1 * (double) input2 + "");
                        kali = false;
                    }
                    if (bagi == true) {
                        hasil.setText((double) input1 / (double) input2 + "");
                        bagi = false;
                    }
                }
            }
        });
        main_button_bagi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasil.getText().length() == 0){
                    hasil.setText("");
                } else {
                    input1 = Double.parseDouble(hasil.getText() + "");
                    bagi = true;
                    hasil.setText(null);
                }
            }
        });
    }
}