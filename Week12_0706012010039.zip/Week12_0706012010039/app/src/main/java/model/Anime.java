package model;

import android.os.Parcel;
import android.os.Parcelable;

public class Anime implements Parcelable {

    private String title, penulis, image_path;
    private int episode;

    public Anime() {
        this.title = "";
        this.penulis = "";
        this.image_path = "";
        this.episode = 0;
    }
    public Anime(String title, String penulis, int episode) {
        this.title = title;
        this.penulis = penulis;
        this.image_path = "";
        this.episode = episode;
    }
    public Anime(String title, String penulis, String image_path, int episode) {
        this.title = title;
        this.penulis = penulis;
        this.image_path = image_path;
        this.episode = episode;
    }

    protected Anime(Parcel in) {
        title = in.readString();
        penulis = in.readString();
        image_path = in.readString();
        episode = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(penulis);
        dest.writeString(image_path);
        dest.writeInt(episode);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Anime> CREATOR = new Creator<Anime>() {
        @Override
        public Anime createFromParcel(Parcel in) {
            return new Anime(in);
        }

        @Override
        public Anime[] newArray(int size) {
            return new Anime[size];
        }
    };

    public String getNama() {
        return title;
    }

    public void setNama(String title) {
        this.title = title;
    }

    public String getPenulis() {
        return penulis;
    }

    public void setPenulis(String penulis) {
        this.penulis = penulis;
    }

    public String getImage_path() {
        return image_path;
    }

    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }

    public int getJumlah() {
        return episode;
    }

    public void setJumlah(int episode) {
        this.episode = episode;
    }
}
