package com.example.progtech;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.regex.Pattern;

import model.User;

public class MainActivity extends AppCompatActivity {

    private TextInputLayout main_textinput_email, main_textinput_password;
    private Button main_button_login, main_button_transparent;
    private ArrayList<User> listUser;
    private Boolean validateEmail, validatePass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        main_textinput_email = findViewById(R.id.main_textinput_email);
        main_textinput_password = findViewById(R.id.main_textinput_password);
        main_button_login = findViewById(R.id.main_button_login);
        main_button_transparent = findViewById(R.id.Register_button_transparent);
        validateEmail = false;
        validatePass = false;

        listUser = new ArrayList<User>();
        listUser.add(new User("krishna@gmail.com", "Krishna", "1@Krishna"));

        main_button_transparent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), RegisterActivity.class);
                startActivity(intent);
            }
        });

        main_button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = main_textinput_email.getEditText().getText().toString().trim();
                String password = main_textinput_password.getEditText().getText().toString().trim();

                if (validateEmail && validatePass) {
                    for (int i = 0; i < listUser.size(); i++) {
                        User tempUser = listUser.get(i);
                        if ((tempUser.getNama().equalsIgnoreCase(email) || tempUser.getEmail().equalsIgnoreCase(email)) && tempUser.getPassword().equalsIgnoreCase(password)){
                            Intent intent = new Intent(getBaseContext(), HomeActivity.class);
                            intent.putExtra("IDuser", tempUser);
                            finish();
                            startActivity(intent);
                            Toast.makeText(getApplicationContext(), "Account Created!", Toast.LENGTH_SHORT).show();
                            break;
                        } else {
                            Toast.makeText(getApplicationContext(), "Unable to Sign Up. Wrong Email / Password.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    main_textinput_email.setError("Please correct the email column");
                    main_textinput_password.setError("Please correct the password column");
                }
            }
        });

        main_textinput_email.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String email = main_textinput_email.getEditText().getText().toString().trim();

                Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile("[a-zA-Z0-9+._%-+]{1,256}" + "@"
                        + "[a-zA-Z0-9][a-zA-Z0-9-]{0,64}" + "(" + "."
                        + "[a-zA-Z0-9][a-zA-Z0-9-]{0,25}" + ")+");
                if (email.isEmpty()) {
                    main_textinput_email.setError("Please fill the Email column");
                    validateEmail = false;
//                    main_button_login.setEnabled(false);
                } else {
                    if (!EMAIL_ADDRESS_PATTERN.matcher(email).matches()) {
                        main_textinput_email.setError("Wrong format Email");
                        validateEmail = false;
                    } else {
                        if(!EMAIL_ADDRESS_PATTERN.matcher(email).matches()){
                            main_textinput_email.setError("Wrong format email");
                            validateEmail = false;
                        }else{
                            main_textinput_email.setError("");
                            validateEmail = true;
//                            main_button_login.setEnabled(true);
                        }
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        main_textinput_password.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = main_textinput_password.getEditText().getText().toString().trim();

                Pattern PASSWORD_PATTERN = Pattern.compile("[a-zA-Z0-9\\!\\@\\#\\$]{0,20}");

                if (password.isEmpty()) {
                    main_textinput_password.setError("Please fill the password column");
                    validatePass = false;
//                    main_button_login.setEnabled(false);
                } else {
                    if (password.length() < 8 || password.length() > 20) {
                        main_textinput_password.setError("Password must be 8 to 20 characters");
                        validatePass = false;
                    } else if (!PASSWORD_PATTERN.matcher(password).matches()) {
                        main_textinput_password.setError("Must contain a - z, A-Z, @, #, $");
                        validatePass = false;
                    } else {
                        main_textinput_password.setError("");
                        validatePass = true;
//                        main_button_login.setEnabled(true);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}
